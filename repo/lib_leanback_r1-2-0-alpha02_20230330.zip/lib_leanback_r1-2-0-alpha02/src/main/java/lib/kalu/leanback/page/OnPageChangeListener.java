package lib.kalu.leanback.page;

public interface OnPageChangeListener {

    void onLeft();

    void onRight();
}
